# AutoHub - Android Auto & Araç İçi Kontrol Merkezi

Modern koyu tema (Dark Automotive UI), Android Auto `CarAppService` entegrasyonu, Spotify/YouTube/Google kısayolları, `MediaProjection` tabanlı ekran yansıtma servisi ve yüklü telefon uygulamalarını başlatıcı (App Launcher) içeren Android Studio (Kotlin + Jetpack Compose) projesidir.

## Kurulum
1. Bu klasörü **Android Studio** ile açın (`Open Project`).
2. Gradle senkronizasyonunun tamamlanmasını bekleyin.
3. Telefonunuzu USB/Wi-Fi Debugging ile bağlayın ve `Run 'app'` ile cihazınıza yükleyin.
4. Android Auto test ortamı için Android Studio **Desktop Head Unit (DHU)** kullanabilirsiniz.

## Önemli Android Auto Platform Notu
Google Play ve Android Auto güvenlik politikaları gereği, sürüş esnasında video oynatma (YouTube), web tarayıcı (Google) ve tam ekran telefon yansıtma özellikleri resmi Play Store sürümlerinde kısıtlıdır; bu özellikler araç **Park Modu** veya Android Auto Geliştirici Seçenekleri ("Bilinmeyen Kaynaklar" etkin) üzerinden test edilmelidir.
