package com.autohub.car.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.autohub.car.mirror.ScreenMirrorService
import com.autohub.car.ui.theme.*
import com.autohub.car.web.CarWebPortalActivity

data class PhoneAppItem(
    val name: String,
    val packageName: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AutoHubTheme {
                AutoHubDashboard()
            }
        }
    }
}

@Composable
fun AutoHubDashboard() {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) }
    var mirroringActive by remember { mutableStateOf(ScreenMirrorService.isMirroring) }

    val projectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(context, ScreenMirrorService::class.java).apply {
                putExtra(ScreenMirrorService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenMirrorService.EXTRA_DATA, result.data)
            }
            context.startForegroundService(serviceIntent)
            mirroringActive = true
            Toast.makeText(context, "Ekran yansıtma başlatıldı", Toast.LENGTH_SHORT).show()
        }
    }

    val installedApps = remember { loadInstalledApps(context) }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(AutoBgDark)
    ) {
        // Sol Modern Araç Dock Menüsü
        Column(
            modifier = Modifier
                .width(88.dp)
                .fillMaxHeight()
                .background(AutoSurface)
                .padding(vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = Icons.Default.DirectionsCar,
                contentDescription = "AutoHub",
                tint = AutoCyan,
                modifier = Modifier.size(34.dp)
            )

            Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
                DockButton(Icons.Default.GridView, "Ana Menü", selectedTab == 0) { selectedTab = 0 }
                DockButton(Icons.Default.Apps, "Uygulamalar", selectedTab == 1) { selectedTab = 1 }
                DockButton(Icons.Default.Cast, "Yansıt", selectedTab == 2) { selectedTab = 2 }
            }

            IconButton(onClick = {
                if (mirroringActive) {
                    context.stopService(Intent(context, ScreenMirrorService::class.java))
                    mirroringActive = false
                } else {
                    val pm = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    projectionLauncher.launch(pm.createScreenCaptureIntent())
                }
            }) {
                Icon(
                    imageVector = if (mirroringActive) Icons.Default.StopCircle else Icons.Default.ScreenShare,
                    contentDescription = "Yansıtma",
                    tint = if (mirroringActive) Color(0xFFEF4444) else AutoEmerald
                )
            }
        }

        // Ana İçerik Alanı
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            Text(
                text = when (selectedTab) {
                    0 -> "AutoHub Araç Kontrol Merkezi"
                    1 -> "Telefondaki Tüm Uygulamalar"
                    else -> "Telefon Ekranı Yansıtma"
                },
                color = AutoTextPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Android Auto uyumlu modern kontrol paneli",
                color = AutoTextSecondary,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(20.dp))

            when (selectedTab) {
                0 -> QuickHubGrid(
                    onOpenSpotify = { launchPackage(context, "com.spotify.music", "Spotify") },
                    onOpenYouTube = { openWeb(context, "https://m.youtube.com", "YouTube") },
                    onOpenGoogle = { openWeb(context, "https://www.google.com", "Google") },
                    onOpenMirror = { selectedTab = 2 },
                    onOpenApps = { selectedTab = 1 }
                )
                1 -> InstalledAppsGrid(installedApps) { pkg ->
                    launchPackage(context, pkg.packageName, pkg.name)
                }
                2 -> MirrorControlPanel(
                    isMirroring = mirroringActive,
                    onToggleMirror = {
                        if (mirroringActive) {
                            context.stopService(Intent(context, ScreenMirrorService::class.java))
                            mirroringActive = false
                        } else {
                            val pm = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                            projectionLauncher.launch(pm.createScreenCaptureIntent())
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun DockButton(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) AutoCyan.copy(alpha = 0.2f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(10.dp)
    ) {
        Icon(icon, contentDescription = label, tint = if (selected) AutoCyan else AutoTextSecondary)
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, fontSize = 10.sp, color = if (selected) AutoCyan else AutoTextSecondary)
    }
}

@Composable
fun QuickHubGrid(
    onOpenSpotify: () -> Unit,
    onOpenYouTube: () -> Unit,
    onOpenGoogle: () -> Unit,
    onOpenMirror: () -> Unit,
    onOpenApps: () -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 180.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { HubCard("Spotify", "Müzik & Çalma Listeleri", Icons.Default.MusicNote, Color(0xFF1DB954), onOpenSpotify) }
        item { HubCard("YouTube", "Video Portalı (Park Modu)", Icons.Default.PlayCircle, Color(0xFFFF0033), onOpenYouTube) }
        item { HubCard("Google", "Arama & Web Tarayıcı", Icons.Default.Search, Color(0xFF4285F4), onOpenGoogle) }
        item { HubCard("Ekran Yansıtma", "Telefon Ekranını Yansıt", Icons.Default.CastConnected, AutoCyan, onOpenMirror) }
        item { HubCard("Telefon Uygulamaları", "Yüklü Uygulamalara Eriş", Icons.Default.Apps, Color(0xFFA855F7), onOpenApps) }
    }
}

@Composable
fun HubCard(title: String, subtitle: String, icon: ImageVector, accent: Color, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(AutoCard, accent.copy(alpha = 0.18f))
                )
            )
            .clickable(onClick = onClick)
            .padding(20.dp)
    ) {
        Icon(icon, contentDescription = title, tint = accent, modifier = Modifier.size(36.dp))
        Spacer(modifier = Modifier.height(14.dp))
        Text(title, color = AutoTextPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(4.dp))
        Text(subtitle, color = AutoTextSecondary, fontSize = 12.sp)
    }
}

@Composable
fun InstalledAppsGrid(apps: List<PhoneAppItem>, onLaunch: (PhoneAppItem) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 150.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(apps) { app ->
            Column(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(AutoCard)
                    .clickable { onLaunch(app) }
                    .padding(16.dp)
            ) {
                Icon(Icons.Default.Android, contentDescription = app.name, tint = AutoEmerald)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = app.name,
                    color = AutoTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun MirrorControlPanel(isMirroring: Boolean, onToggleMirror: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(AutoCard)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.ScreenShare,
            contentDescription = null,
            tint = if (isMirroring) AutoEmerald else AutoCyan,
            modifier = Modifier.size(56.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = if (isMirroring) "Ekran Yansıtma Aktif" else "Telefon Ekranını Yansıtmaya Hazır",
            color = AutoTextPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "MediaProjection VirtualDisplay ile telefon ekranınızı araç moduna aktarır.",
            color = AutoTextSecondary,
            fontSize = 14.sp
        )
        Spacer(modifier = Modifier.height(20.dp))
        Button(
            onClick = onToggleMirror,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isMirroring) Color(0xFFEF4444) else AutoCyan
            )
        ) {
            Text(if (isMirroring) "Yansıtmayı Durdur" else "Ekran Yansıtmayı Başlat")
        }
    }
}

fun loadInstalledApps(context: Context): List<PhoneAppItem> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN, null).apply {
        addCategory(Intent.CATEGORY_LAUNCHER)
    }
    return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        .filter { it.activityInfo.packageName != context.packageName }
        .map { PhoneAppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        .sortedBy { it.name.lowercase() }
}

fun launchPackage(context: Context, packageName: String, label: String) {
    val intent = context.packageManager.getLaunchIntentForPackage(packageName)
    if (intent != null) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    } else {
        Toast.makeText(context, "$label yüklü değil", Toast.LENGTH_SHORT).show()
    }
}

fun openWeb(context: Context, url: String, title: String) {
    val intent = Intent(context, CarWebPortalActivity::class.java).apply {
        putExtra("EXTRA_URL", url)
        putExtra("EXTRA_TITLE", title)
    }
    context.startActivity(intent)
}
