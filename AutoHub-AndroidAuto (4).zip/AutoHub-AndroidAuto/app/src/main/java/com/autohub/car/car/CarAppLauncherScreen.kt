package com.autohub.car.car

import android.content.Intent
import android.content.pm.PackageManager
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ItemList
import androidx.car.app.model.ListTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.Template

class CarAppLauncherScreen(carContext: CarContext) : Screen(carContext) {

    override fun onGetTemplate(): Template {
        val listBuilder = ItemList.Builder()
        val pm = carContext.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val apps = pm.queryIntentActivities(mainIntent, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != carContext.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
            .take(6) // Car App Library liste limiti uyumluluğu için ilk 6 uygulama

        if (apps.isEmpty()) {
            listBuilder.addItem(
                Row.Builder()
                    .setTitle("Uygulama bulunamadı")
                    .addText("Telefonunuzdaki uygulamalar listelenemedi.")
                    .build()
            )
        } else {
            apps.forEach { resolveInfo ->
                val appName = resolveInfo.loadLabel(pm).toString()
                val pkgName = resolveInfo.activityInfo.packageName
                listBuilder.addItem(
                    Row.Builder()
                        .setTitle(appName)
                        .addText(pkgName)
                        .setOnClickListener {
                            val launch = pm.getLaunchIntentForPackage(pkgName)
                            if (launch != null) {
                                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                carContext.startActivity(launch)
                            } else {
                                CarToast.makeText(carContext, "$appName açılamadı.", CarToast.LENGTH_SHORT).show()
                            }
                        }
                        .build()
                )
            }
        }

        return ListTemplate.Builder()
            .setTitle("Telefondaki Uygulamalar")
            .setHeaderAction(Action.BACK)
            .setSingleList(listBuilder.build())
            .build()
    }
}
