package com.autohub.car.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val AutoBgDark = Color(0xFF090D16)
val AutoSurface = Color(0xFF131B2B)
val AutoCard = Color(0xFF1A2438)
val AutoCyan = Color(0xFF06B6D4)
val AutoEmerald = Color(0xFF10B981)
val AutoTextPrimary = Color(0xFFF8FAFC)
val AutoTextSecondary = Color(0xFF94A3B8)

private val AutoDarkScheme = darkColorScheme(
    primary = AutoCyan,
    secondary = AutoEmerald,
    background = AutoBgDark,
    surface = AutoSurface,
    onBackground = AutoTextPrimary,
    onSurface = AutoTextPrimary
)

@Composable
fun AutoHubTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AutoDarkScheme,
        content = content
    )
}
