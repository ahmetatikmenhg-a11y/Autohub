package com.autohub.car.car

import android.content.Intent
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.CarIcon
import androidx.car.app.model.GridItem
import androidx.car.app.model.GridTemplate
import androidx.car.app.model.ItemList
import androidx.car.app.model.MessageTemplate
import androidx.car.app.model.Template
import androidx.core.graphics.drawable.IconCompat
import com.autohub.car.R
import com.autohub.car.web.CarWebPortalActivity

class AutoHubHomeScreen(carContext: CarContext) : Screen(carContext) {

    override fun onGetTemplate(): Template {
        return try {
            val gridBuilder = ItemList.Builder()

            gridBuilder.addItem(
                GridItem.Builder()
                    .setTitle("Spotify")
                    .setText("Müzik & Podcast")
                    .setImage(createAppIcon(R.drawable.ic_car_spotify))
                    .setOnClickListener {
                        launchPhoneApp("com.spotify.music", "Spotify")
                    }
                    .build()
            )

            gridBuilder.addItem(
                GridItem.Builder()
                    .setTitle("YouTube")
                    .setText("Video (Park Modu)")
                    .setImage(createAppIcon(R.drawable.ic_car_youtube))
                    .setOnClickListener {
                        openWebPortal("https://m.youtube.com", "YouTube")
                    }
                    .build()
            )

            gridBuilder.addItem(
                GridItem.Builder()
                    .setTitle("Google")
                    .setText("Web & Arama")
                    .setImage(createAppIcon(R.drawable.ic_car_google))
                    .setOnClickListener {
                        openWebPortal("https://www.google.com", "Google")
                    }
                    .build()
            )

            gridBuilder.addItem(
                GridItem.Builder()
                    .setTitle("Ekran Yansıt")
                    .setText("Canlı Telefon Ekranı")
                    .setImage(createAppIcon(R.drawable.ic_car_mirror))
                    .setOnClickListener {
                        CarToast.makeText(
                            carContext,
                            "Ekran yansıtma izni için telefon ekranından onay verin.",
                            CarToast.LENGTH_LONG
                        ).show()
                        val launchIntent = carContext.packageManager
                            .getLaunchIntentForPackage(carContext.packageName)
                            ?.apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                putExtra("EXTRA_START_MIRROR", true)
                            }
                        if (launchIntent != null) {
                            carContext.startActivity(launchIntent)
                        }
                    }
                    .build()
            )

            gridBuilder.addItem(
                GridItem.Builder()
                    .setTitle("Tüm Uygulamalar")
                    .setText("Telefondaki Uygulamalar")
                    .setImage(createAppIcon(R.drawable.ic_car_apps))
                    .setOnClickListener {
                        screenManager.push(CarAppLauncherScreen(carContext))
                    }
                    .build()
            )

            GridTemplate.Builder()
                .setTitle("AutoHub Araç Merkezi")
                .setHeaderAction(Action.APP_ICON)
                .setSingleList(gridBuilder.build())
                .build()
        } catch (e: Exception) {
            MessageTemplate.Builder("AutoHub hazır. Hata: ${e.localizedMessage ?: "Bilinmeyen"}")
                .setTitle("AutoHub")
                .setHeaderAction(Action.APP_ICON)
                .build()
        }
    }

    private fun createAppIcon(resId: Int): CarIcon {
        return CarIcon.Builder(IconCompat.createWithResource(carContext, resId)).build()
    }

    private fun launchPhoneApp(packageName: String, label: String) {
        val intent = carContext.packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            carContext.startActivity(intent)
        } else {
            CarToast.makeText(carContext, "$label telefonunuzda yüklü değil.", CarToast.LENGTH_SHORT).show()
        }
    }

    private fun openWebPortal(url: String, title: String) {
        val intent = Intent(carContext, CarWebPortalActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra("EXTRA_URL", url)
            putExtra("EXTRA_TITLE", title)
        }
        carContext.startActivity(intent)
    }
}
