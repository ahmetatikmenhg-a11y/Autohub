package com.autohub.car.car

import android.content.Intent
import android.net.Uri
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.CarColor
import androidx.car.app.model.CarIcon
import androidx.car.app.model.GridItem
import androidx.car.app.model.GridTemplate
import androidx.car.app.model.ItemList
import androidx.car.app.model.Template
import androidx.core.graphics.drawable.IconCompat
import com.autohub.car.web.CarWebPortalActivity

class AutoHubHomeScreen(carContext: CarContext) : Screen(carContext) {

    override fun onGetTemplate(): Template {
        val gridBuilder = ItemList.Builder()

        // 1. Spotify
        gridBuilder.addItem(
            GridItem.Builder()
                .setTitle("Spotify")
                .setText("Müzik & Podcast")
                .setImage(createColoredIcon(android.R.drawable.ic_media_play, 0xFF1DB954.toInt()))
                .setOnClickListener {
                    launchPhoneApp("com.spotify.music", "Spotify")
                }
                .build()
        )

        // 2. YouTube
        gridBuilder.addItem(
            GridItem.Builder()
                .setTitle("YouTube")
                .setText("Video (Park Modu)")
                .setImage(createColoredIcon(android.R.drawable.ic_media_ff, 0xFFFF0033.toInt()))
                .setOnClickListener {
                    openWebPortal("https://m.youtube.com", "YouTube")
                }
                .build()
        )

        // 3. Google Arama
        gridBuilder.addItem(
            GridItem.Builder()
                .setTitle("Google")
                .setText("Web & Arama")
                .setImage(createColoredIcon(android.R.drawable.ic_menu_search, 0xFF4285F4.toInt()))
                .setOnClickListener {
                    openWebPortal("https://www.google.com", "Google")
                }
                .build()
        )

        // 4. Telefon Ekranı Yansıtma
        gridBuilder.addItem(
            GridItem.Builder()
                .setTitle("Ekran Yansıt")
                .setText("Canlı Telefon Ekranı")
                .setImage(createColoredIcon(android.R.drawable.ic_menu_gallery, 0xFF06B6D4.toInt()))
                .setOnClickListener {
                    CarToast.makeText(
                        carContext,
                        "Ekran yansıtma izni için telefon ekranından onay verin.",
                        CarToast.LENGTH_LONG
                    ).show()
                    val launchIntent = carContext.packageManager
                        .getLaunchIntentForPackage(carContext.packageName)
                        ?.apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            putExtra("EXTRA_START_MIRROR", true)
                        }
                    if (launchIntent != null) {
                        carContext.startActivity(launchIntent)
                    }
                }
                .build()
        )

        // 5. Yüklü Uygulamalar
        gridBuilder.addItem(
            GridItem.Builder()
                .setTitle("Tüm Uygulamalar")
                .setText("Telefondaki Uygulamalar")
                .setImage(createColoredIcon(android.R.drawable.ic_menu_manage, 0xFFA855F7.toInt()))
                .setOnClickListener {
                    screenManager.push(CarAppLauncherScreen(carContext))
                }
                .build()
        )

        return GridTemplate.Builder()
            .setTitle("AutoHub Araç Merkezi")
            .setHeaderAction(Action.APP_ICON)
            .setSingleList(gridBuilder.build())
            .build()
    }

    private fun createColoredIcon(resId: Int, colorHex: Int): CarIcon {
        return CarIcon.Builder(IconCompat.createWithResource(carContext, resId))
            .setTint(CarColor.createCustom(colorHex, colorHex))
            .build()
    }

    private fun launchPhoneApp(packageName: String, label: String) {
        val intent = carContext.packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            carContext.startActivity(intent)
        } else {
            CarToast.makeText(carContext, "$label telefonunuzda yüklü değil.", CarToast.LENGTH_SHORT).show()
        }
    }

    private fun openWebPortal(url: String, title: String) {
        val intent = Intent(carContext, CarWebPortalActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra("EXTRA_URL", url)
            putExtra("EXTRA_TITLE", title)
        }
        carContext.startActivity(intent)
    }
}
